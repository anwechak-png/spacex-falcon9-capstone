"""Step 6 - Interactive visual analytics with Folium.

Map layers:
  * a circle + label for every launch site
  * green/red marker clusters for successful / failed launches per site
  * mouse-position read-out
  * proximity analysis: distance (Haversine) from CCAFS SLC-40 to the nearest
    coastline, railway, highway and city, drawn as labelled lines

NOTE: the proximity coordinates are approximate points picked from the map;
refine them with the MousePosition read-out if you need more precision.
Output: outputs/launch_sites_map.html
"""
from math import asin, cos, radians, sin, sqrt

import folium
import pandas as pd
from folium.plugins import MarkerCluster, MousePosition

from config import OUT, WRANGLED_CSV


def haversine_km(lat1, lon1, lat2, lon2):
    lat1, lon1, lat2, lon2 = map(radians, (lat1, lon1, lat2, lon2))
    a = sin((lat2 - lat1) / 2) ** 2 + cos(lat1) * cos(lat2) * sin((lon2 - lon1) / 2) ** 2
    return 6371.0088 * 2 * asin(sqrt(a))


PROXIMITY = {  # name: (lat, lon) near CCAFS SLC-40
    "Coastline": (28.56342, -80.56798),
    "Railway": (28.57206, -80.58528),
    "Highway": (28.56420, -80.57080),
    "City (Titusville)": (28.61200, -80.80780),
}


def main():
    df = pd.read_csv(WRANGLED_CSV)
    sites = df.groupby("LaunchSite")[["Latitude", "Longitude"]].first().reset_index()

    nasa = (29.559684888503615, -95.0830971930759)
    m = folium.Map(location=nasa, zoom_start=5)
    MousePosition().add_to(m)

    for _, s in sites.iterrows():
        loc = [s.Latitude, s.Longitude]
        folium.Circle(loc, radius=1000, color="#d35400", fill=True).add_child(
            folium.Popup(s.LaunchSite)).add_to(m)
        folium.Marker(
            loc,
            icon=folium.DivIcon(
                icon_size=(20, 20), icon_anchor=(0, 0),
                html=f'<div style="font-size:12px;color:#d35400"><b>{s.LaunchSite}</b></div>'),
        ).add_to(m)

    cluster = MarkerCluster().add_to(m)
    for _, r in df.iterrows():
        color = "green" if r.Class == 1 else "red"
        folium.Marker(
            [r.Latitude, r.Longitude],
            icon=folium.Icon(color="white", icon_color=color, icon="info-sign"),
            popup=f"Flight {r.FlightNumber} - {'Success' if r.Class == 1 else 'Failure'}",
        ).add_to(cluster)

    base = sites[sites.LaunchSite.str.contains("40")].iloc[0]
    base_loc = (base.Latitude, base.Longitude)
    rows = []
    for name, (lat, lon) in PROXIMITY.items():
        d = haversine_km(*base_loc, lat, lon)
        rows.append({"Feature": name, "Distance_km": round(d, 2)})
        folium.Marker(
            [lat, lon],
            icon=folium.DivIcon(html=f'<div style="font-size:12px;color:#1f618d">'
                                     f'<b>{name}: {d:.2f} km</b></div>')).add_to(m)
        folium.PolyLine([base_loc, (lat, lon)], weight=2, color="#1f618d").add_to(m)

    m.save(OUT / "launch_sites_map.html")
    pd.DataFrame(rows).to_csv(OUT / "proximity_distances.csv", index=False)
    print(pd.DataFrame(rows))


if __name__ == "__main__":
    main()
