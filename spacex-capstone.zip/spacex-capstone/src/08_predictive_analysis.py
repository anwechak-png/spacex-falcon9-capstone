"""Step 8 - Predictive analysis: will the Falcon 9 first stage land?

Models: Logistic Regression, SVM, Decision Tree, KNN
Method: standardise -> 80/20 split (random_state=2) -> GridSearchCV (cv=10)
Outputs: outputs/model_results.csv, figures/confusion_matrix_<model>.png,
         figures/model_accuracy.png, outputs/best_model.txt
"""
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import ConfusionMatrixDisplay, f1_score
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier

from config import FEATURES_CSV, FIGS, OUT

MODELS = {
    "Logistic Regression": (
        LogisticRegression(max_iter=1000),
        {"C": [0.01, 0.1, 1], "penalty": ["l2"], "solver": ["lbfgs"]},
    ),
    "SVM": (
        SVC(),
        {"kernel": ["linear", "rbf", "poly", "sigmoid"],
         "C": np.logspace(-3, 3, 5), "gamma": np.logspace(-3, 3, 5)},
    ),
    "Decision Tree": (
        DecisionTreeClassifier(random_state=12345),
        {"criterion": ["gini", "entropy"], "splitter": ["best", "random"],
         "max_depth": [2 * n for n in range(1, 10)],
         "max_features": ["sqrt", "log2"],
         "min_samples_leaf": [1, 2, 4], "min_samples_split": [2, 5, 10]},
    ),
    "KNN": (
        KNeighborsClassifier(),
        {"n_neighbors": list(range(1, 11)), "algorithm": ["auto", "ball_tree", "kd_tree", "brute"],
         "p": [1, 2]},
    ),
}


def main():
    data = pd.read_csv(FEATURES_CSV)
    X = data.drop(columns="Class")
    y = data["Class"].to_numpy()
    X = StandardScaler().fit_transform(X)
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=2)
    print(f"Train {X_tr.shape}, test {X_te.shape}")

    rows = []
    for name, (est, grid) in MODELS.items():
        gs = GridSearchCV(est, grid, cv=10, n_jobs=-1).fit(X_tr, y_tr)
        pred = gs.predict(X_te)
        rows.append({
            "Model": name,
            "CV accuracy": round(gs.best_score_, 4),
            "Test accuracy": round(gs.score(X_te, y_te), 4),
            "Test F1": round(f1_score(y_te, pred), 4),
            "Best params": gs.best_params_,
        })
        ConfusionMatrixDisplay.from_predictions(
            y_te, pred, display_labels=["did not land", "landed"], cmap="Blues")
        plt.title(f"Confusion matrix - {name}")
        plt.savefig(FIGS / f"confusion_matrix_{name.replace(' ', '_').lower()}.png",
                    dpi=150, bbox_inches="tight")
        plt.close()

    res = pd.DataFrame(rows).sort_values("Test accuracy", ascending=False)
    res.to_csv(OUT / "model_results.csv", index=False)
    print(res.to_string(index=False))

    plt.figure(figsize=(7, 4))
    plt.bar(res["Model"], res["Test accuracy"], color="#3b6ea5")
    plt.ylim(0, 1)
    plt.ylabel("Test accuracy")
    plt.title("Model comparison")
    plt.xticks(rotation=20)
    plt.savefig(FIGS / "model_accuracy.png", dpi=150, bbox_inches="tight")
    plt.close()

    best = res.iloc[0]
    (OUT / "best_model.txt").write_text(
        f"Best model: {best['Model']}\nTest accuracy: {best['Test accuracy']}\n"
        f"Params: {best['Best params']}\n")


if __name__ == "__main__":
    main()
