"""Step 4 - EDA with data visualisation (seaborn / matplotlib).

Charts (all saved to figures/):
  1 FlightNumber vs PayloadMass          (scatter, hue=Class)
  2 FlightNumber vs LaunchSite           (scatter)
  3 PayloadMass vs LaunchSite            (scatter)
  4 Success rate by Orbit                (bar)
  5 FlightNumber vs Orbit                (scatter)
  6 PayloadMass vs Orbit                 (scatter)
  7 Yearly success-rate trend            (line)
Finally builds the one-hot feature table used for modelling.
"""
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

from config import FEATURES_CSV, FIGS, WRANGLED_CSV

sns.set_theme(style="whitegrid")


def scatter(df, x, y, name, title):
    g = sns.catplot(data=df, x=x, y=y, hue="Class", aspect=4, height=4)
    g.set_xlabels(x)
    g.set_ylabels(y)
    plt.title(title)
    plt.savefig(FIGS / f"{name}.png", dpi=150, bbox_inches="tight")
    plt.close()


def main():
    df = pd.read_csv(WRANGLED_CSV, parse_dates=["Date"])

    scatter(df, "FlightNumber", "PayloadMass", "01_flight_vs_payload",
            "Flight number vs payload mass (Class 1 = landed)")
    scatter(df, "FlightNumber", "LaunchSite", "02_flight_vs_site",
            "Flight number vs launch site")
    scatter(df, "PayloadMass", "LaunchSite", "03_payload_vs_site",
            "Payload mass vs launch site")

    orbit_rate = df.groupby("Orbit")["Class"].mean().sort_values()
    plt.figure(figsize=(9, 4.5))
    orbit_rate.plot(kind="bar", color="#3b6ea5")
    plt.ylabel("Success rate")
    plt.title("Success rate by orbit type")
    plt.savefig(FIGS / "04_success_by_orbit.png", dpi=150, bbox_inches="tight")
    plt.close()

    scatter(df, "FlightNumber", "Orbit", "05_flight_vs_orbit", "Flight number vs orbit")
    scatter(df, "PayloadMass", "Orbit", "06_payload_vs_orbit", "Payload mass vs orbit")

    yearly = df.assign(Year=df["Date"].dt.year).groupby("Year")["Class"].mean()
    plt.figure(figsize=(8, 4.5))
    plt.plot(yearly.index, yearly.values, marker="o", color="#c0392b")
    plt.xlabel("Year")
    plt.ylabel("Success rate")
    plt.title("Yearly launch success trend")
    plt.savefig(FIGS / "07_yearly_trend.png", dpi=150, bbox_inches="tight")
    plt.close()
    print(yearly.round(3))

    # ---- feature engineering ----
    feats = df[["FlightNumber", "PayloadMass", "Orbit", "LaunchSite", "Flights",
                "GridFins", "Reused", "Legs", "LandingPad", "Block", "ReusedCount",
                "Serial"]].copy()
    feats["LandingPad"] = feats["LandingPad"].fillna("NoPad")
    feats["Block"] = feats["Block"].fillna(feats["Block"].median())
    feats = pd.get_dummies(
        feats, columns=["Orbit", "LaunchSite", "LandingPad", "Serial"], dtype=float
    )
    feats = feats.astype(float)
    feats["Class"] = df["Class"].values
    feats.to_csv(FEATURES_CSV, index=False)
    print(f"Feature table {feats.shape} -> {FEATURES_CSV}")


if __name__ == "__main__":
    main()
