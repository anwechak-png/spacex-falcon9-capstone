"""Shared paths and constants for the SpaceX Falcon 9 capstone."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
FIGS = ROOT / "figures"
OUT = ROOT / "outputs"
for p in (DATA, FIGS, OUT):
    p.mkdir(parents=True, exist_ok=True)

API_BASE = "https://api.spacexdata.com/v4"
WIKI_URL = (
    "https://en.wikipedia.org/w/index.php"
    "?title=List_of_Falcon_9_and_Falcon_Heavy_launches&oldid=1027686922"
)

RAW_API_CSV = DATA / "spacex_api_raw.csv"
WIKI_CSV = DATA / "spacex_web_scraped.csv"
WRANGLED_CSV = DATA / "dataset_wrangled.csv"
FEATURES_CSV = DATA / "dataset_features.csv"
DB_PATH = DATA / "spacex.db"

# Outcomes treated as an unsuccessful landing (Class = 0)
BAD_OUTCOMES = {
    "False Ocean", "False RTLS", "False ASDS",
    "None None", "None ASDS", "None RTLS",
}
