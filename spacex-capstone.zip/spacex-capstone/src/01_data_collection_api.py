"""Step 1 - Data collection with the SpaceX REST API (v4).

Flow:  GET /launches/past -> keep single-core / single-payload Falcon 9 launches
       -> look up rocket, launchpad, payload and core by id (cached)
       -> assemble a tidy DataFrame -> data/spacex_api_raw.csv
"""
from functools import lru_cache

import pandas as pd
import requests

from config import API_BASE, RAW_API_CSV


@lru_cache(maxsize=None)
def get(path: str):
    r = requests.get(f"{API_BASE}/{path}", timeout=30)
    r.raise_for_status()
    return r.json()


def main():
    launches = pd.json_normalize(get("launches/past"))
    launches = launches[
        ["rocket", "payloads", "launchpad", "cores", "flight_number", "date_utc"]
    ]
    # keep launches with exactly one core and one payload
    launches = launches[
        (launches["cores"].map(len) == 1) & (launches["payloads"].map(len) == 1)
    ].copy()
    launches["core"] = launches["cores"].map(lambda c: c[0])
    launches["payload"] = launches["payloads"].map(lambda p: p[0])
    launches["date"] = pd.to_datetime(launches["date_utc"]).dt.date
    launches = launches[launches["date"] <= pd.Timestamp("2020-11-13").date()]

    rows = []
    for _, l in launches.iterrows():
        rocket = get(f"rockets/{l['rocket']}")
        pad = get(f"launchpads/{l['launchpad']}")
        payload = get(f"payloads/{l['payload']}")
        core_ref = l["core"]
        core = get(f"cores/{core_ref['core']}") if core_ref["core"] else {}
        rows.append(
            {
                "FlightNumber": l["flight_number"],
                "Date": l["date"],
                "BoosterVersion": rocket["name"],
                "PayloadMass": payload.get("mass_kg"),
                "Orbit": payload.get("orbit"),
                "Customer": ", ".join(payload.get("customers") or []),
                "LaunchSite": pad["name"],
                "Outcome": f"{core_ref['landing_success']} {core_ref['landing_type']}",
                "Flights": core_ref["flight"],
                "GridFins": core_ref["gridfins"],
                "Reused": core_ref["reused"],
                "Legs": core_ref["legs"],
                "LandingPad": core_ref["landpad"],
                "Block": core.get("block"),
                "ReusedCount": core.get("reuse_count"),
                "Serial": core.get("serial"),
                "Longitude": pad["longitude"],
                "Latitude": pad["latitude"],
            }
        )

    df = pd.DataFrame(rows)
    df = df[df["BoosterVersion"] == "Falcon 9"].reset_index(drop=True)
    df["FlightNumber"] = range(1, len(df) + 1)
    df.to_csv(RAW_API_CSV, index=False)
    print(f"Saved {len(df)} Falcon 9 launches -> {RAW_API_CSV}")


if __name__ == "__main__":
    main()
