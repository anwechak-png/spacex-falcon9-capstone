"""Step 5 - EDA with SQL (SQLite, via pandas + sqlite3).

Runs 10 queries covering launch sites, payloads, success rates, rankings and
time analysis. Results are printed and written to outputs/sql_results.md.
"""
import sqlite3

import pandas as pd

from config import DB_PATH, OUT, WRANGLED_CSV

QUERIES = {
    "1. Unique launch sites":
        "SELECT DISTINCT LaunchSite FROM SPACEX",
    "2. Five records where launch site begins with 'CCSFS' or 'CCAFS'":
        "SELECT * FROM SPACEX WHERE LaunchSite LIKE 'CC%' LIMIT 5",
    "3. Total payload mass carried for NASA customers":
        "SELECT SUM(PayloadMass) AS total_kg FROM SPACEX WHERE Customer LIKE '%NASA%'",
    "4. Average payload mass of booster version Falcon 9":
        "SELECT AVG(PayloadMass) AS avg_kg FROM SPACEX WHERE BoosterVersion = 'Falcon 9'",
    "5. Date of first successful ground-pad landing":
        "SELECT MIN(Date) AS first_ground_landing FROM SPACEX WHERE Outcome = 'True RTLS'",
    "6. Boosters with successful drone-ship landing and payload 4000-6000 kg":
        "SELECT DISTINCT Serial FROM SPACEX WHERE Outcome = 'True ASDS' "
        "AND PayloadMass BETWEEN 4000 AND 6000",
    "7. Total number of each landing outcome":
        "SELECT Outcome, COUNT(*) AS n FROM SPACEX GROUP BY Outcome ORDER BY n DESC",
    "8. Boosters that carried the maximum payload mass":
        "SELECT DISTINCT Serial, PayloadMass FROM SPACEX "
        "WHERE PayloadMass = (SELECT MAX(PayloadMass) FROM SPACEX)",
    "9. 2015 failed drone-ship landings (month, booster, site)":
        "SELECT substr(Date,6,2) AS month, Serial, LaunchSite FROM SPACEX "
        "WHERE Outcome = 'False ASDS' AND substr(Date,1,4) = '2015'",
    "10. Rank landing outcomes between 2010-06-04 and 2017-03-20":
        "SELECT Outcome, COUNT(*) AS n FROM SPACEX "
        "WHERE Date BETWEEN '2010-06-04' AND '2017-03-20' "
        "GROUP BY Outcome ORDER BY n DESC",
}


def main():
    df = pd.read_csv(WRANGLED_CSV)
    df["Date"] = df["Date"].astype(str).str[:10]
    with sqlite3.connect(DB_PATH) as con:
        df.to_sql("SPACEX", con, if_exists="replace", index=False)
        md = ["# EDA with SQL - results\n"]
        for title, sql in QUERIES.items():
            res = pd.read_sql_query(sql, con)
            print(f"\n{title}\n{res.to_string(index=False)}")
            md.append(f"## {title}\n```sql\n{sql}\n```\n\n{res.to_markdown(index=False)}\n")
    (OUT / "sql_results.md").write_text("\n".join(md))


if __name__ == "__main__":
    main()
