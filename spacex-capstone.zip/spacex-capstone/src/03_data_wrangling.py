"""Step 3 - Data wrangling.

* inspect missing values and dtypes
* impute PayloadMass with the mean, keep LandingPad nulls (no pad used)
* count launches per site / orbit / outcome
* create the binary label  Class  (1 = booster landed, 0 = did not)
"""
import pandas as pd

from config import BAD_OUTCOMES, RAW_API_CSV, WRANGLED_CSV


def main():
    df = pd.read_csv(RAW_API_CSV)
    print("Missing values (%):\n", (df.isna().mean() * 100).round(2), "\n")
    print("dtypes:\n", df.dtypes, "\n")

    df["PayloadMass"] = df["PayloadMass"].fillna(df["PayloadMass"].mean())
    df["Date"] = pd.to_datetime(df["Date"])

    print("Launches per site:\n", df["LaunchSite"].value_counts(), "\n")
    print("Launches per orbit:\n", df["Orbit"].value_counts(), "\n")
    outcomes = df["Outcome"].value_counts()
    print("Landing outcomes:\n", outcomes, "\n")

    df["Class"] = df["Outcome"].map(lambda o: 0 if o in BAD_OUTCOMES else 1)
    print(f"Overall success rate: {df['Class'].mean():.2%}")

    df.to_csv(WRANGLED_CSV, index=False)
    print(f"Saved -> {WRANGLED_CSV}")


if __name__ == "__main__":
    main()
