"""Step 7 - Interactive dashboard with Plotly Dash.

* Dropdown: all sites or a single launch site
* Pie chart: total successes by site (all) or success vs failure (single site)
* Range slider: payload mass (kg)
* Scatter: payload mass vs launch outcome, coloured by booster version

Run:  python src/07_dash_app.py   ->  http://127.0.0.1:8050
"""
import pandas as pd
import plotly.express as px
from dash import Dash, Input, Output, dcc, html

from config import WRANGLED_CSV

df = pd.read_csv(WRANGLED_CSV)
df["Outcome label"] = df["Class"].map({1: "Success", 0: "Failure"})
min_p, max_p = float(df["PayloadMass"].min()), float(df["PayloadMass"].max())

app = Dash(__name__)
app.title = "SpaceX Launch Records Dashboard"
app.layout = html.Div(
    style={"fontFamily": "sans-serif", "maxWidth": "1100px", "margin": "auto"},
    children=[
        html.H1("SpaceX Launch Records Dashboard", style={"textAlign": "center"}),
        dcc.Dropdown(
            id="site-dropdown",
            options=[{"label": "All Sites", "value": "ALL"}]
            + [{"label": s, "value": s} for s in sorted(df["LaunchSite"].unique())],
            value="ALL", searchable=True, clearable=False,
            placeholder="Select a Launch Site here",
        ),
        dcc.Graph(id="success-pie-chart"),
        html.P("Payload range (kg):"),
        dcc.RangeSlider(
            id="payload-slider", min=0, max=10000, step=1000,
            marks={i: f"{i}" for i in range(0, 10001, 2500)},
            value=[min_p, max_p],
        ),
        dcc.Graph(id="success-payload-scatter-chart"),
    ],
)


@app.callback(Output("success-pie-chart", "figure"), Input("site-dropdown", "value"))
def update_pie(site):
    if site == "ALL":
        return px.pie(df, values="Class", names="LaunchSite",
                      title="Total successful launches by site")
    sub = df[df["LaunchSite"] == site]["Outcome label"].value_counts().reset_index()
    sub.columns = ["Outcome", "count"]
    return px.pie(sub, values="count", names="Outcome",
                  title=f"Success vs failure at {site}")


@app.callback(
    Output("success-payload-scatter-chart", "figure"),
    Input("site-dropdown", "value"),
    Input("payload-slider", "value"),
)
def update_scatter(site, payload_range):
    lo, hi = payload_range
    sub = df[(df["PayloadMass"] >= lo) & (df["PayloadMass"] <= hi)]
    title = "Payload vs outcome - all sites"
    if site != "ALL":
        sub = sub[sub["LaunchSite"] == site]
        title = f"Payload vs outcome - {site}"
    return px.scatter(sub, x="PayloadMass", y="Class", color="BoosterVersion",
                      title=title, labels={"Class": "Landing outcome (1 = success)"})


if __name__ == "__main__":
    app.run(debug=False)
