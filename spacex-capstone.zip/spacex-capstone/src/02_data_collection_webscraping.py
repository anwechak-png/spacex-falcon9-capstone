"""Step 2 - Data collection by web scraping Wikipedia (BeautifulSoup).

Flow:  GET Wikipedia launch list (fixed revision) -> find 'wikitable' tables
       -> parse every row that starts with a flight number
       -> data/spacex_web_scraped.csv
"""
import re

import pandas as pd
import requests
from bs4 import BeautifulSoup

from config import WIKI_CSV, WIKI_URL


def clean(cell) -> str:
    for sup in cell.find_all("sup"):
        sup.decompose()
    return re.sub(r"\s+", " ", cell.get_text(" ", strip=True)).strip()


def main():
    html = requests.get(WIKI_URL, timeout=30, headers={"User-Agent": "capstone/1.0"}).text
    soup = BeautifulSoup(html, "html.parser")
    tables = soup.find_all("table", "wikitable plainrowheaders collapsible")

    records = []
    for table in tables:
        for row in table.find_all("tr"):
            th = row.find("th")
            if th is None or not th.get_text(strip=True).isdigit():
                continue
            cells = [clean(td) for td in row.find_all("td")]
            if len(cells) < 8:
                continue
            date_time = cells[0]
            date_m = re.search(r"\d{1,2} \w+ \d{4}", date_time)
            time_m = re.search(r"\d{2}:\d{2}", date_time)
            records.append(
                {
                    "FlightNo": int(th.get_text(strip=True)),
                    "Date": date_m.group(0) if date_m else None,
                    "Time": time_m.group(0) if time_m else None,
                    "VersionBooster": cells[1],
                    "LaunchSite": cells[2],
                    "Payload": cells[3],
                    "PayloadMass": cells[4],
                    "Orbit": cells[5],
                    "Customer": cells[6],
                    "LaunchOutcome": cells[7],
                    "BoosterLanding": cells[8] if len(cells) > 8 else None,
                }
            )

    df = pd.DataFrame(records)
    df.to_csv(WIKI_CSV, index=False)
    print(f"Scraped {len(df)} launches from {len(tables)} tables -> {WIKI_CSV}")


if __name__ == "__main__":
    main()
