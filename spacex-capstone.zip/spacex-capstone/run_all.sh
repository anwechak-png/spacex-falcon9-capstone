#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/src"
python 01_data_collection_api.py
python 02_data_collection_webscraping.py
python 03_data_wrangling.py
python 04_eda_visualization.py
python 05_eda_sql.py
python 06_folium_map.py
python 08_predictive_analysis.py
echo "Done. Launch the dashboard with: python 07_dash_app.py"
