# Data Science Capstone Project Report
## Predicting SpaceX Falcon 9 First-Stage Landing Success

**GitHub repository:** `https://github.com/<your-username>/spacex-capstone`  <!-- TODO: replace after you push -->

> Fill the `[RESULT]` placeholders with the numbers produced by the scripts in `outputs/` and `figures/`.
> Every section below maps to one item of the grading criteria (1.3 – 1.15).

---

## 1. Executive Summary  *(criterion 1.3)*

**Methods:** Launch data was collected from the SpaceX REST API and by scraping Wikipedia, wrangled with pandas (imputation, label creation), explored with seaborn charts and SQL (SQLite), mapped with Folium, explored interactively in a Plotly Dash app, and modelled with four classifiers (Logistic Regression, SVM, Decision Tree, KNN) tuned by 10-fold GridSearchCV.

**Key results:**
- Overall landing success rate: `[RESULT]`; success rate rises with flight number / year (reuse learning curve).
- Best model: `[RESULT]` with test accuracy `[RESULT]` (see `outputs/model_results.csv`).
- Orbits such as LEO / ISS / SSO show higher success than GTO.

## 2. Introduction  *(criterion 1.4)*

**Background.** SpaceX advertises Falcon 9 launches at about $62 M, versus $165 M+ for competitors, because the first stage can be recovered and reused. Whether the first stage lands determines the true cost of a launch.

**Problem.** Given launch parameters (payload mass, orbit, launch site, booster block, grid fins, legs, reuse count …), **predict whether the Falcon 9 first stage will land successfully**, so that a competing bidder can estimate the cost of a launch.

## 3. Methodology

### 3.1 Data Collection – SpaceX API  *(criterion 1.5)*
```
GET /launches/past
   -> filter: 1 core, 1 payload, Falcon 9, date <= 2020-11-13
   -> GET /rockets/{id}      (booster version)
   -> GET /launchpads/{id}   (site, lat, lon)
   -> GET /payloads/{id}     (mass, orbit, customer)
   -> GET /cores/{id}        (block, reuse count, serial)
   -> assemble DataFrame -> data/spacex_api_raw.csv
```
Code: `<GitHub URL>/blob/main/src/01_data_collection_api.py`

### 3.2 Data Collection – Web Scraping  *(criterion 1.6)*
```
requests.get(Wikipedia list of Falcon 9 launches, fixed revision)
   -> BeautifulSoup parse -> select 'wikitable' tables
   -> for each row with a flight number: extract date, time, booster, site,
      payload, mass, orbit, customer, outcome, landing
   -> data/spacex_web_scraped.csv
```
Code: `<GitHub URL>/blob/main/src/02_data_collection_webscraping.py`

### 3.3 Data Wrangling  *(criterion 1.7)*
- Checked missing values and dtypes; **PayloadMass** nulls → mean imputation; **LandingPad** nulls kept (= no pad used).
- Counted launches per site, orbit and landing outcome.
- Created label `Class`: 1 = `True ASDS / True Ocean / True RTLS`, 0 = `False …` / `None …`.
- Code: `<GitHub URL>/blob/main/src/03_data_wrangling.py`

### 3.4 EDA with Data Visualization  *(criterion 1.8)*

| Chart | Purpose |
|---|---|
| FlightNumber vs PayloadMass (scatter) | does experience / payload affect landing? |
| FlightNumber vs LaunchSite (scatter) | success pattern per site |
| PayloadMass vs LaunchSite (scatter) | payload limits per site |
| Success rate by Orbit (bar) | which orbits are riskiest |
| FlightNumber vs Orbit, PayloadMass vs Orbit (scatter) | orbit-specific patterns |
| Yearly success trend (line) | learning curve over time |

Features were one-hot encoded for modelling. Code: `<GitHub URL>/blob/main/src/04_eda_visualization.py`

### 3.5 EDA with SQL  *(criterion 1.9)*
Ten queries (unique sites, `LIKE 'CC%'`, NASA payload total, average payload for Falcon 9, first ground-pad landing, drone-ship successes with 4000–6000 kg, outcome counts, max-payload boosters, 2015 failed drone-ship landings, outcome ranking 2010-06-04 → 2017-03-20).
Code: `<GitHub URL>/blob/main/src/05_eda_sql.py` · results: `outputs/sql_results.md`

### 3.6 Interactive Visual Analytics  *(criterion 1.10)*
- **Folium map** – launch-site circles/labels, success/failure marker clusters, mouse position, distance lines to coastline, railway, highway, city. Code: `<GitHub URL>/blob/main/src/06_folium_map.py`
- **Plotly Dash app** – site dropdown, success pie chart, payload range slider, payload-vs-outcome scatter. Code: `<GitHub URL>/blob/main/src/07_dash_app.py`

### 3.7 Predictive Analysis
Standardise → 80/20 split (`random_state=2`) → GridSearchCV (cv=10) for four models → compare accuracy, F1 and confusion matrices. Code: `<GitHub URL>/blob/main/src/08_predictive_analysis.py`

## 4. Results

### 4.1 EDA with Visualization  *(criterion 1.11)*
Insert from `figures/`: `01_flight_vs_payload.png`, `02_flight_vs_site.png`, `03_payload_vs_site.png`, `04_success_by_orbit.png`, `05_flight_vs_orbit.png`, `06_payload_vs_orbit.png`, `07_yearly_trend.png`.

Insights to write up:
- Later flights land more often (flight-number scatter, yearly trend).
- Heavy payloads succeed more on some orbits (LEO/ISS); GTO is the hardest.
- Success by site: `[RESULT]`.

### 4.2 EDA with SQL  *(criterion 1.12)*
Insert the tables from `outputs/sql_results.md` (launch sites, payload sums/averages, first ground landing date, success/failure counts, outcome ranking, 2015 failures).

### 4.3 Folium Map  *(criterion 1.13)*
Insert screenshots of `outputs/launch_sites_map.html`: (a) all sites with labels, (b) green/red clusters, (c) proximity lines with distances from `outputs/proximity_distances.csv`.
Findings: sites are close to the coast (launch over water for safety) and relatively far from cities.

### 4.4 Plotly Dash  *(criterion 1.14)*
Insert screenshots: pie of successes by site, pie for the best site, payload-vs-outcome scatter for several slider ranges.

### 4.5 Predictive Analysis  *(criterion 1.15)*
- Model comparison table from `outputs/model_results.csv`; bar chart `figures/model_accuracy.png`.
- Confusion matrices: `figures/confusion_matrix_*.png`.
- **Best model:** `[RESULT]` (`outputs/best_model.txt`). Explain why it wins (e.g. small dataset, mostly separable classes).

## 5. Conclusion
- First-stage landing is predictable from pre-launch parameters with ~`[RESULT]` % accuracy.
- Success improves with flight number, grid fins/legs, newer blocks and reuse.
- Limitations: small dataset (~90 rows), test-set false positives dominate errors.
- Innovative next steps: cost model (landing probability × $ saved), gradient boosting / ensembles, live Dash deployment, adding weather data.

## 6. Appendix
- Repo structure and run instructions: see `README.md`.
